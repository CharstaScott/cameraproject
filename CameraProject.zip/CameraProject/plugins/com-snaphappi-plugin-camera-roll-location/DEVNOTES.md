# swift packages to consider
https://github.com/SwiftyJSON/SwiftyJSON
https://github.com/ankurp/Dollar

# cordova plugins
https://github.com/glowmar/phonegap-plugin-assetslib (objC)