import PackageDescription

let package = Package(name: "Dollar")
