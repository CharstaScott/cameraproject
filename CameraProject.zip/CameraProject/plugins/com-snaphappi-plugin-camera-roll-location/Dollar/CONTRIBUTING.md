# Contributing 

1. Please fork this project
2. Implement new methods or changes in the `Dollar.swift` file in `Dollar` folder.
3. Write tests in `DollarTests.swift` file as needed.
4. Write appropriate comments in code and docs in the `README.md`.
5. Submit a pull request.
