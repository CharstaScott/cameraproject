cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "com-snaphappi-plugin-camera-roll-location.CameraRollLocation",
    "file": "plugins/com-snaphappi-plugin-camera-roll-location/www/CameraRollLocation.js",
    "pluginId": "com-snaphappi-plugin-camera-roll-location",
    "clobbers": [
      "cordova.plugins.CameraRollLocation",
      "snappi_CameraRollLocation"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-whitelist": "1.3.3",
  "com-snaphappi-plugin-camera-roll-location": "0.1.0"
};
// BOTTOM OF METADATA
});